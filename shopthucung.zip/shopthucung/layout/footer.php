<footer>
    <div class="footer">
        <div class="footer__title">
            <span>Liên hệ</span>
            <div class="footer__social">
                <a href="facebook.com/trieuetam" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-github"></i></a>
                <a href="#"><i class="fab fa-google"></i></a>
            </div>
        </div>
    </div>
    
    <div class="footer__info">

        <div class="footer__info-content">
            <h3>Giới thiệu</h3>
            <p>Website quản lý, mua bán thú cưng</p>
        </div>



        <div class="footer__info-content">
            <h3>Liên hệ</h3>
            <p>Địa chỉ: 475 Điện Biên Phủ, Hutech khu A,B</p>
            <p>Email: trieuetam@gmail.com</p>
            <p>Sđt: 123456789</p>
        </div>

        <div class="footer__info-content">
            <h3>Fanpage</h3>
            <p><iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FC%25E1%25BB%25ADa-h%25C3%25A0ng-S%25E1%25BA%25A3n-ph%25E1%25BA%25A9m-D%25C3%25A0nh-cho-Th%25C3%25BA-C%25C6%25B0ng-100178969197228%2F%3Fref%3Dpages_you_manage&tabs=timeline&width=300px&height=150px&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="100%" height="150px" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe></p>
        </div>

    </div>

    <div class="footer__copyright">
        <center> 2022 All rights reserved.</center>
    </div>
</footer>